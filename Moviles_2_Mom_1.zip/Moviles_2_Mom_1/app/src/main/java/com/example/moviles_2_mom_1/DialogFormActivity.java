package com.example.moviles_2_mom_1;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class DialogFormActivity extends DialogFragment {


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        //Alert dialog de Layout completo
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View v = inflater.inflate(R.layout.activity_form,null);
        final EditText et_registro_cedula = v.findViewById(R.id.et_registro_cedula);
        final EditText et_registro_nombre = v.findViewById(R.id.et_registro_nombre);
        final EditText et_registro_apellido = v.findViewById(R.id.et_registro_apellido);
        final EditText et_registro_contrasena = v.findViewById(R.id.et_registro_contrasena);

        builder.setView(v)
                .setPositiveButton("Enviar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Información enviada", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Información cancelada", Toast.LENGTH_SHORT).show();
                    }
                });



        //Para hacer un alert dialog sencillo
        /*
        builder.setMessage("Por favor ingrese todos los datos")
                .setTitle("Formulario de Registro")
                .setPositiveButton("Enviar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getContext(), "Registro aceptado", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }

                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getContext(), "Registro cancelado", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                });
*/

        return builder.create();




    }
}
