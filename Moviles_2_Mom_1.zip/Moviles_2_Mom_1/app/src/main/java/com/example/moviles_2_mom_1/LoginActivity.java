package com.example.moviles_2_mom_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    //Declaración de atributos
    private EditText et_login_usuario, et_login_contrasena;
    private Button btn_login_ingresar, btn_login_registrarse;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_login_usuario = findViewById(R.id.et_login_usuario);
        et_login_contrasena = findViewById(R.id.et_login_contrasena);
        btn_login_ingresar = findViewById(R.id.btn_login_ingresar);
        btn_login_registrarse = findViewById(R.id.btn_login_registrarse);


        btn_login_ingresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ingresar = new Intent(LoginActivity.this, ListActivity.class);
                startActivity(ingresar);
            }
        });


        btn_login_registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                DialogFormActivity dialogFormActivity = new DialogFormActivity();
                dialogFormActivity.show(fragmentManager, "tagAlerta");

            }
        });

    }
}
