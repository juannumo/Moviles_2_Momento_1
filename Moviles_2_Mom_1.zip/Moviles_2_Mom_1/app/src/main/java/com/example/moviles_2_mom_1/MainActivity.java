package com.example.moviles_2_mom_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Definición de atributos
    private Button btn_main_continuar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        btn_main_continuar = findViewById(R.id.btn_main_continuar);


        btn_main_continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent continuar = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(continuar);

            }
        });



    }
}
